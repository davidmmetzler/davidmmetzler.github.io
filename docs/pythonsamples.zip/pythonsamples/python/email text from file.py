# ---------------------------------------------------------------------------
# sending an email with python
# this is set up for gmail accounts.
# ---------------------------------------------------------------------------

import os
import subprocess
import smtplib
import mimetypes
from smtplib import SMTP
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
#the location of your error log
log = r"C:\Users\username\log.txt"



# this will open the log file
fp = open(log, 'rb')
# loading the content of the error log into the body of the message
msg = MIMEText(fp.read())
fp.close()
msg['Subject'] = 'What you would like the title to be' #Subject of the email
to = 'davemetzler@halker.com' #can add recipents with a good old comma
gmail_user = 'example' #gmail username
gmail_pwd = 'password' #gmail password
smtpserver = smtplib.SMTP("smtp.gmail.com",587)
smtpserver.ehlo()
smtpserver.starttls()
smtpserver.ehlo
smtpserver.login(gmail_user, gmail_pwd)
smtpserver.sendmail(gmail_user, to, msg.as_string())
smtpserver.close()

#clear the error log of all contents
open(log,"w").close()
