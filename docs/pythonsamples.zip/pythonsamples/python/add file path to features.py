import  arcpy
from arcpy import env
import os
import time
""" Sometimes, especially when merging a lot of data regularly it is helpful to know what the source file of all of your points was. this way if there is a problem with that piece of information you can trace it all
the way back to the source.
This handy dandy script will walk through a root folder and list all subfolders. it will then look at those folders and list the feature classes within
from there it will add a field called shpname and calculate it to equal the full path of the feaure class.
In the end you will have a feature class where every feature has the root file associated with it!"""


y = r"C:\SomeFolder" #Your folder that contains all of the subfolders

def main(x):
    try:
        import arcpy, sys, traceback, os, glob, shutil
        arcpy.env.overwriteOutput = True
        masterFolder = x

        #collect a list of subfolders in master folder
        arcpy.env.workspace = masterFolder
        arcpy.ListWorkspaces('','Folder')
        subfolderLst = arcpy.ListWorkspaces('','Folder')
        print subfolderLst
        for subfolder in subfolderLst:
            arcpy.env.workspace = subfolder
            fcLst = arcpy.ListFeatureClasses()
            
            for fc in fcLst:
                file = fc in fcLst
                filename = "'" + arcpy.env.workspace + os.sep + fc + "'"
                print filename
                arcpy.AddField_management(fc, 'shpname','text')
               
                arcpy.CalculateField_management(fc, 'shpname', filename, "PYTHON" )
                arcpy.env.overwriteOutput = True
                
                

    except:
        print arcpy.GetMessages(2)
  
    

main(y)
